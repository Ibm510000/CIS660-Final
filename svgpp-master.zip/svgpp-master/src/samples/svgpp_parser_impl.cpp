#include <svgpp/parser/external_function/parse_path_data_impl.hpp>
#include <svgpp/parser/external_function/parse_transform_impl.hpp>

SVGPP_PARSE_PATH_DATA_IMPL(const char *, double)
SVGPP_PARSE_TRANSFORM_IMPL(const char *, double)
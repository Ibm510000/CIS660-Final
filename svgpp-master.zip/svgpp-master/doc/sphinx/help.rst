Help and Feedback
---------------------

Library support and development `forum <http://groups.google.com/d/forum/svgpp>`_

Issue tracker at `GitHub <https://github.com/svgpp/svgpp/issues>`_

Author can be contacted at olegmax@gmail.com

Acknowledgements
-----------------------

Thanks to `Atlassian <https://www.atlassian.com/>`_ Company for providing free 
Bamboo continuous integration `server <https://svgcpp.atlassian.net/builds/browse/SVG>`_ 
that made it easy to test library immediately in different environments.